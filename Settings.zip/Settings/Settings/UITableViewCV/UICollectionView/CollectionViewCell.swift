//
//  CollectionViewCell.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 8/31/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var IconsIMG: UIImageView!
    @IBOutlet weak var IconName: UILabel!
    @IBOutlet weak var B: UIView!
    
    @IBOutlet weak var FullTXT: UILabel!
    @IBOutlet weak var BitTXT: UILabel!
    @IBOutlet weak var MaxTXT: UILabel!
    
    @IBOutlet weak var Process: UIProgressView!
    
    
}
