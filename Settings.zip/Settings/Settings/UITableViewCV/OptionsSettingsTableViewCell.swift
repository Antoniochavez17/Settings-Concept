//
//  OptionsSettingsTableViewCell.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 8/31/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class OptionsSettingsTableViewCell: UITableViewCell {

    var IconsImage = ["General", "WiFi", "Bluetooth", "CellularData", "PersonalHotspot", "BatteryUsage", "AppStore", ""]
    var IconName = ["Storage", "Wifi", "Bluetooth", "Cellular", "HotSpot", "Battery", "Subscription", ""]
    
    @IBOutlet weak var CollectionOptions: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        CollectionOptions.delegate = self
        CollectionOptions.dataSource = self
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension OptionsSettingsTableViewCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        var optionsCells: CollectionViewCell!

                  
        if indexPath.row == 7 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            
            let imageAttachment = NSTextAttachment()
            imageAttachment.image = UIImage(systemName: "plus.circle.fill")?.withTintColor(.systemGray)
            
            imageAttachment.bounds = CGRect(x: 0, y: 0, width: 45, height: 45)
            
            let fullString = NSAttributedString(attachment: imageAttachment)
            
            optionsCells?.MaxTXT.attributedText = fullString
            optionsCells?.MaxTXT.textAlignment = .center
            optionsCells?.MaxTXT.sizeToFit()
            optionsCells?.Process.progress = 0.75
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.isHidden = true
            
            optionsCells?.BitTXT.isHidden = true
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = false
            
            return optionsCells!
            
        } else if indexPath.row == 6  {
            
            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "Price: ", attributes: [.foregroundColor: UIColor.systemGray])
            fullString.append(NSAttributedString(string: "$10.99\n", attributes: [.foregroundColor: UIColor.label]))
            fullString.append(NSAttributedString(string: "Name: ", attributes: [.foregroundColor: UIColor.systemGray]))
            fullString.append(NSAttributedString(string: "Disney + \n", attributes: [.foregroundColor: UIColor.label]))
            
            fullString.append(NSAttributedString(string: "\nPayment was due to 9/12/20.", attributes: [.foregroundColor: UIColor.systemGray]))
            

            
            optionsCells?.FullTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 0.75
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.isHidden = true
            
            optionsCells?.BitTXT.isHidden = true
            optionsCells?.FullTXT.isHidden = false
            optionsCells?.MaxTXT.isHidden = true

            
            return optionsCells!
            
        } else if indexPath.row == 5 {
            
            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
             
            optionsCells?.B.layer.cornerRadius = 11
             optionsCells?.B.layer.masksToBounds = true
             optionsCells?.IconName.text = IconName[indexPath.row]
             optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
             
             let fullString = NSMutableAttributedString(string: "75% ", attributes: [.foregroundColor: UIColor.systemYellow])
             fullString.append(NSAttributedString(string: "of 100%\n\n", attributes: [.foregroundColor: UIColor.systemGray]))
             fullString.append(NSAttributedString(string: "Your battery may need to replacements.", attributes: [.foregroundColor: UIColor.systemGray]))

             
             optionsCells?.BitTXT.attributedText = fullString
             optionsCells?.FullTXT.sizeToFit()
             optionsCells?.Process.progress = 0.75
             optionsCells?.isUserInteractionEnabled = false
             optionsCells?.FullTXT.numberOfLines = 0
             optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
             optionsCells?.Process.progressTintColor = UIColor.systemYellow
             
            optionsCells?.BitTXT.isHidden = false
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = true
            
             return optionsCells!
            
        } else if indexPath.row == 4 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
           optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "5 ", attributes: [.foregroundColor: UIColor.systemGreen])
            fullString.append(NSAttributedString(string: "of 5GB\n\n", attributes: [.foregroundColor: UIColor.systemGray]))
            fullString.append(NSAttributedString(string: "You can use HotSpot to share your data!", attributes: [.foregroundColor: UIColor.systemGray]))

            
            optionsCells?.BitTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 1
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.progressTintColor = UIColor.systemGreen
            
            optionsCells?.BitTXT.isHidden = false
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = true
            
            return optionsCells!
            
        } else if indexPath.row == 4 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
           optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "5 ", attributes: [.foregroundColor: UIColor.systemGreen])
            fullString.append(NSAttributedString(string: "of 5GB\n\n", attributes: [.foregroundColor: UIColor.systemGray]))
            fullString.append(NSAttributedString(string: "You can use HotSpot to share your data!", attributes: [.foregroundColor: UIColor.systemGray]))

            
            optionsCells?.BitTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 1
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.progressTintColor = UIColor.systemGreen
            
            optionsCells?.BitTXT.isHidden = false
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = true
            
            return optionsCells!
            
        } else if indexPath.row == 3 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "7.5 ", attributes: [.foregroundColor: UIColor.systemYellow])
            fullString.append(NSAttributedString(string: "of 15GB\n\n", attributes: [.foregroundColor: UIColor.systemGray]))
            fullString.append(NSAttributedString(string: "Your data is still good use to go!", attributes: [.foregroundColor: UIColor.systemGray]))

            
            optionsCells?.BitTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 0.55
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.progressTintColor = UIColor.systemYellow
            
            optionsCells?.BitTXT.isHidden = false
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = true
            
            
            return optionsCells!
            
        } else if indexPath.row == 2 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "Battery Usage: ", attributes: [.foregroundColor: UIColor.systemGray])
                       
            fullString.append(NSAttributedString(string: "75%\n", attributes: [.foregroundColor: UIColor.systemYellow]))
            
            fullString.append(NSAttributedString(string: "Name: Antonio's AirPods\n", attributes: [.foregroundColor: UIColor.systemGray]))
                       fullString.append(NSAttributedString(string: "Status: ", attributes: [.foregroundColor: UIColor.lightGray]))

                       fullString.append(NSAttributedString(string: "Connected", attributes: [.foregroundColor: UIColor.systemGreen]))
            
                       optionsCells?.FullTXT.attributedText = fullString
                       optionsCells?.FullTXT.sizeToFit()
                       optionsCells?.Process.progress = 0.75
                       optionsCells?.Process.progressTintColor = UIColor.systemYellow
                       optionsCells?.isUserInteractionEnabled = false
                       optionsCells?.FullTXT.numberOfLines = 0
                       optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
                       optionsCells?.Process.isHidden = false
                       
                       optionsCells?.BitTXT.isHidden = true
                       optionsCells?.FullTXT.isHidden = false
            optionsCells?.MaxTXT.isHidden = true
            
            return optionsCells!
            
        } else if indexPath.row == 1 {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")
            
            let fullString = NSMutableAttributedString(string: "Status: ", attributes: [.foregroundColor: UIColor.systemGray])
            fullString.append(NSAttributedString(string: "Internet Connected\n", attributes: [.foregroundColor: UIColor.systemGreen]))
            fullString.append(NSAttributedString(string: "Name: Sumannua's WI-Fi \nSignal: 75%", attributes: [.foregroundColor: UIColor.systemGray]))

            
            optionsCells?.FullTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 0.75
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            optionsCells?.Process.isHidden = true
            
            optionsCells?.BitTXT.isHidden = true
            optionsCells?.FullTXT.isHidden = false
            optionsCells?.MaxTXT.isHidden = true
            
            return optionsCells!
            
        } else {

            optionsCells = CollectionOptions.dequeueReusableCell(withReuseIdentifier: "OptionsOne", for: indexPath) as? CollectionViewCell
            
            optionsCells?.B.layer.cornerRadius = 11
            optionsCells?.B.layer.masksToBounds = true
            optionsCells?.IconName.text = IconName[indexPath.row]
            optionsCells?.IconsIMG.image = UIImage(named: "\(IconsImage[indexPath.row])")

            let fullString = NSMutableAttributedString(string: "117.48 ", attributes: [.foregroundColor: UIColor.systemYellow])
            fullString.append(NSAttributedString(string: "of 256GB\n\n", attributes: [.foregroundColor: UIColor.systemGray]))
            fullString.append(NSAttributedString(string: "You are good enough storage space!", attributes: [.foregroundColor: UIColor.systemGray]))

            
            optionsCells?.BitTXT.attributedText = fullString
            optionsCells?.FullTXT.sizeToFit()
            optionsCells?.Process.progress = 0.55
            optionsCells?.isUserInteractionEnabled = false
            optionsCells?.FullTXT.numberOfLines = 0
            optionsCells?.FullTXT.lineBreakMode = .byWordWrapping
            
            optionsCells?.BitTXT.isHidden = false
            optionsCells?.FullTXT.isHidden = true
            optionsCells?.MaxTXT.isHidden = true
            
            return optionsCells!
            
        }
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 160, height: 131)
    }

    
}
