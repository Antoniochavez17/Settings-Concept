//
//  EnableCellsTableViewCell.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 5/23/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class EnableCellsTableViewCell: UITableViewCell {

    @IBOutlet weak var IconsIMG: UIImageView!
    @IBOutlet weak var IconsName: UILabel!
    @IBOutlet weak var BV: UIView!
    
     @IBOutlet weak var BorderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
