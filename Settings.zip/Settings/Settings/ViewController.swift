//
//  ViewController.swift
//  Settings
//
//  Created by Antonio Adrian Chavez on 5/23/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UISearchBarDelegate {

    var icons = [[""], ["AirplaneMode", "WiFi", "Bluetooth", "CellularData"], ["NotificationCenter", "Sounds", "DND", "ScreenTime"], ["General", "ControlCenter", "Display", "Accessibility", "Wallpaper", "Siri", "TouchID", "SOS", "BatteryUsage", "Privacy"], ["AppStore", "Wallet"], ["KeychainSync", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], ["VideoSubscriber"]]
          
          var TitleStg = [[""], ["Airplane Mode", "Wi-Fi", "Bluetooth", "CellularData"], ["Notification Center", "Sounds & Haptics", "Do Not Distrub", "Screen Time"], ["General", "ControlCenter", "Display & Brightness", "Accessibility", "Wallpaper", "Siri", "TouchID & Passcode", "Emergency SOS", "Battery", "Privacy"], ["iTunes & App Store", "Wallet & Apple Pay"], ["Password & Accounts", "Mail", "Contacts", "Calendar", "Notes", "Reminders", "Voice Memos", "Photo", "Messages", "FaceTime", "Maps", "Compass", "Measure", "Safari", "News", "Stocks", "Health", "Shortcuts"], ["Music", "TV", "Photos", "Camera", "Books", "Podcasts", "Game Center"], ["TV Provider"]]
         
          
          var footertitleStg = [ [""], ["", "Sumannua's Wi-Fi", "On", "On"], ["", "", "On", "On"], ["", "", "", "", "=", "", "", "", "", ""], ["", ""], ["", "=", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], ["", "", "", "", "", "", ""], ["XomxAR XZDINRY"]]
          
       
          
              var countsCells = [ [" "], [" ", " ", " ", " "], [" ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "], [" ", " "], [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " " , " ", " ", " ", " ", " ", " "], [" ", " ", " ", " ", " ", " ", " "], [" "]]

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        self.navigationItem.title = "Settings"
        self.navigationController?.navigationBar.prefersLargeTitles = true
        
        self.navigationController?.navigationItem.largeTitleDisplayMode = .never
                  
        UINavigationBar.appearance().isTranslucent = false
        
        let app = UINavigationBarAppearance()
             
        let navigationBar = self.navigationController?.navigationBar
              
        app.backgroundColor = .clear
        app.configureWithOpaqueBackground()
        app.titleTextAttributes = [.foregroundColor: UIColor.label]
        app.largeTitleTextAttributes = [.foregroundColor: UIColor.label]
        app.backgroundColor = .systemGroupedBackground
        
        self.navigationController?.navigationBar.scrollEdgeAppearance = app
                  
                
        navigationBar!.standardAppearance = app
        navigationBar!.scrollEdgeAppearance = app
             
      // MARK: Navigations Bar Blur
//        // Find size for blur effect.
//        let statusBarHeight = UIApplication.shared.statusBarFrame.size.height
//        let bounds = self.navigationController?.navigationBar.bounds.insetBy(dx: 0, dy: -(statusBarHeight)).offsetBy(dx: 0, dy: -(statusBarHeight))
//        // Create blur effect.
//        let visualEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
//        visualEffectView.frame = bounds!
//
//        // Set navigation bar up.
//        self.navigationController?.navigationBar.isTranslucent = true
//        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
//        self.navigationController?.navigationBar.addSubview(visualEffectView)
//        self.navigationController?.navigationBar.sendSubviewToBack(visualEffectView)
        
        
                  let search = UISearchController(searchResultsController: nil)
                  search.searchBar.delegate = self
                  search.searchResultsUpdater = self as? UISearchResultsUpdating
                  search.searchBar.placeholder = "Search"
        search.searchBar.searchTextField.tintColor = UIColor.gray
        search.searchBar.setImage(UIImage(named: "magnifyingglass")?.withTintColor(UIColor.systemGray), for: .search, state: .normal)
                 
            self.navigationItem.searchController = search
            
        (UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]) ).defaultTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.init(white: 100, alpha: 0.50)]
              
                  let textField = search.searchBar.value(forKey: "searchField") as! UITextField

                  let glassIconView = textField.leftView as! UIImageView
                  glassIconView.image = glassIconView.image?.withRenderingMode(.alwaysTemplate)
                  glassIconView.tintColor = UIColor.systemGray

                  let clearButton = textField.value(forKey: "clearButton") as! UIButton
                  clearButton.setImage(clearButton.imageView?.image?.withRenderingMode(.alwaysTemplate), for: .normal)
                  clearButton.tintColor = UIColor.systemGray
                  
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        
        
        if indexPath.row == 53 {
                   
                   return 47
                   
                   } else if indexPath.row == 52 {
                       
                       return 15
                       
                   } else if indexPath.row == 51 {
                       
                       return 47
                       
                   } else if indexPath.row == 50 {
                       
                       return 47
                       
                   } else if indexPath.row == 49 {
                       
                       return 47
                       
                   } else if indexPath.row == 48 {
                       
                       return 47
                       
                   } else if indexPath.row == 47 {
                       
                       return 47
                       
                   } else if indexPath.row == 46 {
                       
                       return 47
                       
                   } else if indexPath.row == 45 {
                       
                       return 47
                       
                   } else if indexPath.row == 44 {
                       
                       return 15
                       
                   } else if indexPath.row == 43 {
                       
                       return 47
                       
                   } else if indexPath.row == 42 {
                       
                       return 47
                       
                   } else if indexPath.row == 41 {
                       
                       return 47
                       
                   } else if indexPath.row == 40 {
                       
                       return 47
                       
                   } else if indexPath.row == 39 {
                       
                       return 47
                       
                   } else if indexPath.row == 38 {
                       
                       return 47
                       
                   } else if indexPath.row == 37 {
                       
                       return 47
                       
                   } else if indexPath.row == 36 {
                       
                       return 47
                       
                   } else if indexPath.row == 35 {
                       
                       return 47
                       
                   } else if indexPath.row == 34 {
                       
                       return 47
                       
                   } else if indexPath.row == 33 {
                       
                       return 47
                       
                   } else if indexPath.row == 32 {
                       
                       return 47
                       
                   } else if indexPath.row == 31 {
                       
                       return 47
                       
                   } else if indexPath.row == 30 {
                       
                       return 47
                       
                   } else if indexPath.row == 29 {
                       
                       return 47
                       
                   } else if indexPath.row == 28 {
                       
                       return 47
                       
                   } else if indexPath.row == 27 {
                       
                       return 47
                       
                   } else if indexPath.row == 26 {
                       
                       return 15
                       
                   } else if indexPath.row == 25 {
                       
                       return 47
                       
                   } else if indexPath.row == 24 {
                       
                       return 47
                       
                   } else if indexPath.row == 23 {
                       
                       return 15
                       
                   } else if indexPath.row == 22 {
                       
                       return 47
                       
                   } else if indexPath.row == 21 {
                       
                       return 47
                       
                   } else if indexPath.row == 20 {
                       
                       return 47
                       
                   } else if indexPath.row == 19 {
                       
                       return 47
                       
                   } else if indexPath.row == 18 {
                       
                       return 47
                       
                   } else if indexPath.row == 17 {
                       
                       return 47
                       
                   } else if indexPath.row == 16 {
                       
                       return 47
                       
                   } else if indexPath.row == 15 {
                       
                       return 47
                       
                   } else if indexPath.row == 14 {
                      
                       return 47
                       
                       
                   } else if indexPath.row == 13 {
                   
                   return 15
                   
               } else if indexPath.row == 12 {
                   
                   return 47
                   
               } else if indexPath.row == 11 {
                  
                   return 47
                   
                   
               } else if indexPath.row == 10 {
                   
                   return 47
                   
               } else if indexPath.row == 9 {
                   
                   return 47
                   
               } else if indexPath.row == 8 {
                   
                   return 15
                   
               } else if indexPath.row == 7 {
                   
                   return 47
                   
               } else if indexPath.row == 6 {
                   
                   return 47
                   
               } else if indexPath.row == 5 {
                   
                   return 47
                   
               } else if indexPath.row == 4 {
                   
                   return 47
                   
               } else if indexPath.row == 3 {
                   
                   return 15
                   
               } else if indexPath.row == 2 {
                   
                   return 85
                   
               } else if indexPath.row == 1 {
                  
                   return 15
                   
               } else {
                   
                   return 131
                   
               }
        
    
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var optionsCells: OptionsSettingsTableViewCell!
        
       var iCloudCells: iCloudTableViewCell!
                 
        var cells: CellsTableViewCell!
              
        var footerCells: FooterCellsTableViewCell!
              
        var enableCells: EnableCellsTableViewCell!
       
        var spaceCells: SpaceTableViewCell!
        
    
                 
                 
        if indexPath.row == 53 {
                
        footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                       
                       footerCells.IconsIMG.image = UIImage(named: "VideoSubscriber")
                       
                       footerCells.IconsLBL.text = "TV Provider"
            footerCells.IconsFooter.text = "Comast XFINITY"
                   
                    footerCells.BV.layer.cornerRadius = 11
                    footerCells.BV.layer.masksToBounds = true

        
                       return footerCells!
                     
                
        } else if indexPath.row == 52 {
            
            spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
            
            
            return spaceCells!
           
            
        } else if indexPath.row == 51 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "GameCenter")
                           
                           cells.IconsName.text = "Game Center"
                       
            cells.BV.layer.cornerRadius = 11
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = true
            
                           return cells!
            
        } else if indexPath.row == 50 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Podcasts")
                           
                           cells.IconsName.text = "Podcasts"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 49 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "iBooks")
                           
                           cells.IconsName.text = "Books"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 48 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Camera")
                           
                           cells.IconsName.text = "Camera"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 47 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Photos")
                           
                           cells.IconsName.text = "Photos"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 46 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "TVApple")
                           
                           cells.IconsName.text = "TV"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 45 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Music")
                           
                           cells.IconsName.text = "Music"
                       
            cells.BV.layer.cornerRadius = 11
                  cells.BV.layer.masksToBounds = true
            
                  cells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 44 {
            
            
           spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
           
           
           return spaceCells!
            
        } else if indexPath.row == 43 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Shortcuts")
                           
                           cells.IconsName.text = "Shortcuts"
                       
            cells.BV.layer.cornerRadius = 11
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = true
            
                           return cells!
            
        } else if indexPath.row == 42 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Health")
                           
                           cells.IconsName.text = "Health"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 41 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Stocks")
                           
                           cells.IconsName.text = "Stocks"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 40 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "News")
                           
                           cells.IconsName.text = "News"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 39 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Safari")
                           
                           cells.IconsName.text = "Safari"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 38 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Measure")
                           
                           cells.IconsName.text = "Measure"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 37 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Compass")
                           
                           cells.IconsName.text = "Compass"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 36 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "FaceTime")
                           
                           cells.IconsName.text = "FaceTime"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 35 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Messages")
                           
                           cells.IconsName.text = "Messages"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 34 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Photos")
                           
                           cells.IconsName.text = "Photo"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 33 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "VoiceMemos")
                           
                           cells.IconsName.text = "Voice Memos"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 32 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Reminders")
                           
                           cells.IconsName.text = "Reminders"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 31 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Notes")
                           
                           cells.IconsName.text = "Notes"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 30 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Calendar")
                           
                           cells.IconsName.text = "Calendar"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 29 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Contacts")
                           
                           cells.IconsName.text = "Contacts"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 28 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Mail")
                           
                           cells.IconsName.text = "Mail"
                       
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 27 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "KeychainSync")
                           
                           cells.IconsName.text = "Passwords"
                       
            cells.BV.layer.cornerRadius = 11
                  cells.BV.layer.masksToBounds = true
            
                  cells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            
            cells.BorderView.isHidden = false
            
                           return cells!
            
        } else if indexPath.row == 26 {
            
            
            spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
                      
                      
                      return spaceCells!
            
        } else if indexPath.row == 25 {
            
            
          cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                         
                         cells.IconsIMG.image = UIImage(named: "Wallet")
                         
                         cells.IconsName.text = "Wallet & Apple Pay"
                     
                  cells.BV.layer.cornerRadius = 11
                           cells.BV.layer.masksToBounds = true
                   
                           cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
           
            
            cells.BorderView.isHidden = true
            
                           return cells!
            
        } else if indexPath.row == 24 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                         
                         cells.IconsIMG.image = UIImage(named: "AppStore")
                         
                         cells.IconsName.text = "iTunes & App Store"
                     
                   cells.BV.layer.cornerRadius = 11
                           cells.BV.layer.masksToBounds = true
                   
                          cells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
           
            
                           return cells!
            
        } else if indexPath.row == 23 {
            
            
            spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
            
            
            return spaceCells!
            
            
        } else if indexPath.row == 22 {
            
            
           cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                           
                           cells.IconsIMG.image = UIImage(named: "Privacy")
                           
                           cells.IconsName.text = "Privacy"
                       
            cells.BV.layer.cornerRadius = 11
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            cells.BorderView.isHidden = true
            
                           return cells!
            
        } else if indexPath.row == 21 {
            
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "BatteryUsage")
                
                cells.IconsName.text = "Battery"
            
                return cells!
            
            
        } else if indexPath.row == 20 {
            
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "SOS")
                
                cells.IconsName.text = "Emergency SOS"
            
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
                return cells!
            
            
        } else if indexPath.row == 19 {
            
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "TouchID")
                
                cells.IconsName.text = "Face ID & Passcode"
            
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
                return cells!
            
            
        } else if indexPath.row == 18 {
            
            
             cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                                   
                    cells.IconsIMG.image = UIImage(named: "Siri")
                                   
                    cells.IconsName.text = "Siri & Search"
                               
    
                       
                                   return cells!
            
        } else if indexPath.row == 17 {
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "Accessibility")
                
                cells.IconsName.text = "Accessibility"
            
                return cells!
            
        } else if indexPath.row == 16 {
            
            cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                
                cells.IconsIMG.image = UIImage(named: "Display")
                
                cells.IconsName.text = "Display & Brightness"
            
                return cells!
            
            
        } else if indexPath.row == 15 {
                    
              cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                  
                  cells.IconsIMG.image = UIImage(named: "ControlCenter")
                  
                  cells.IconsName.text = "Control Center"
              
                  return cells!
        
        } else if indexPath.row == 14 {
                    
              cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                  
                  cells.IconsIMG.image = UIImage(named: "General")
                  
                  cells.IconsName.text = "General"
              
                  cells.BV.layer.cornerRadius = 11
                  cells.BV.layer.masksToBounds = true
            
                  cells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            
                  return cells!
        
          } else if indexPath.row == 13 {
                    
              spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
              
              
              return spaceCells!
        
          } else if indexPath.row == 12 {
                      
                footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                    
                    footerCells.IconsIMG.image = UIImage(named: "ScreenTime")
                    
                    footerCells.IconsLBL.text = "Screen Time"
                footerCells.IconsFooter.text = "Off"
            
            footerCells.BV.layer.cornerRadius = 11
            footerCells.BV.layer.masksToBounds = true
            footerCells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            footerCells.BorderView.isHidden = true
                    return footerCells!
          
            } else if indexPath.row == 11 {
                        
                 footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                      
                      footerCells.IconsIMG.image = UIImage(named: "DND")
                      
                      footerCells.IconsLBL.text = "Do Not Distrub"
                 
                      footerCells.IconsFooter.text = "On"
            
                      return footerCells!
                  
            
              } else if indexPath.row == 10 {
                          
                   cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                        
                        cells.IconsIMG.image = UIImage(named: "Sounds")
                        
                        cells.IconsName.text = "Sounds & Haptics"
                    
            cells.BV.layer.cornerRadius = 0
            cells.BV.layer.masksToBounds = true
            cells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
                        return cells!
              
                } else if indexPath.row == 9 {
                            
                     cells = tableView.dequeueReusableCell(withIdentifier: "Cells", for: indexPath) as? CellsTableViewCell
                          
                          cells.IconsIMG.image = UIImage(named: "NotificationCenter")
                          
                          cells.IconsName.text = "Notification Center"
                      
                    cells.BV.layer.cornerRadius = 11
                            cells.BV.layer.masksToBounds = true
                    
                           cells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            
                          return cells!
                
                  } else if indexPath.row == 8 {
                    
              spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
              
              
              return spaceCells!
        
          } else if indexPath.row == 7 {
                      
                 footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                                       
                footerCells.IconsIMG.image = UIImage(named: "CellularData")
                                       
                footerCells.IconsLBL.text = "Cellular"
                footerCells.IconsFooter.text = "On"
            
        footerCells.BV.layer.cornerRadius = 11
        footerCells.BV.layer.masksToBounds = true
        footerCells.BV.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            
            footerCells.BorderView.isHidden = true
                                                     
            
            
                 return footerCells!
                             
          
            } else if indexPath.row == 6 {
                        
                  footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                                 
                             
                    footerCells?.IconsIMG?.image = UIImage(named: "Bluetooth")
                                 
                            
                    footerCells.IconsLBL.text = "Bluetooth"
                  footerCells.IconsFooter.text = "On"
                            
                    return footerCells!
            
              }  else if indexPath.row == 5 {
                    
              footerCells = tableView.dequeueReusableCell(withIdentifier: "FooterCells", for: indexPath) as? FooterCellsTableViewCell
                           
                       
              footerCells?.IconsIMG?.image = UIImage(named: "WiFi")
                           
                      
            footerCells.IconsLBL.text = "Wi-Fi"
            footerCells.IconsFooter.text = "Sumannua's Wi-Fi"
                      
              return footerCells!
        
          } else if indexPath.row == 4 {
                  
            enableCells = tableView.dequeueReusableCell(withIdentifier: "EnableCells", for: indexPath) as? EnableCellsTableViewCell
                         
                     
            enableCells?.IconsIMG?.image = UIImage(named: "AirplaneMode")
                         
                    
            enableCells.IconsName.text = "Airplane Mode"

            enableCells.BV.layer.cornerRadius = 11
            enableCells.BV.layer.masksToBounds = true
    
           enableCells.BV.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
                   
            
            return enableCells!
      
        } else if indexPath.row == 3 {
                    
                      
                    spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
                         
                         
                         return spaceCells!
                     
                     
        }  else if indexPath.row == 2 {
                     
                    iCloudCells = tableView.dequeueReusableCell(withIdentifier: "iCloudCells", for: indexPath) as? iCloudTableViewCell
                     
                     iCloudCells.IMG.image = UIImage(named: "Untitled 28")
                     iCloudCells.NameLBL.text = "Antonio Adrian Chavez"
           
//            iCloudCells.BV.layer.borderWidth = 0.10
//            iCloudCells.BV.layer.borderColor = UIColor.white.cgColor
            iCloudCells.BV.layer.cornerRadius = 11
            iCloudCells.BV.layer.masksToBounds = true
            
            
        
            
                     return iCloudCells!
                     
        } else if indexPath.row == 1 {
                             
          spaceCells = tableView.dequeueReusableCell(withIdentifier: "Space", for: indexPath) as? SpaceTableViewCell
                            
                            
                            return spaceCells!
                             
               
        } else {
            
            optionsCells = tableView.dequeueReusableCell(withIdentifier: "Options", for: indexPath) as? OptionsSettingsTableViewCell
            
            
             return optionsCells!
            
            
        }
                   

            
        }
    
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 53
   

        
    }
    
    
    
    
    
    
}
